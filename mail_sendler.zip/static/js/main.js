// static/js/main.js
document.addEventListener('DOMContentLoaded', () => {

  /* ─── helpers ─── */
  const daysLeft = s => {
    try { return Math.floor((new Date(s) - new Date()) / 864e5); }
    catch { return null; }
  };
  const render = (tmpl, row) =>
    tmpl.replace(/\{([A-F]|expiry_days)\}/g,
      (_, k) => k === 'expiry_days' ? row.expiry_days : (row[k] ?? ''));

  let matched = [];                     // кеш строк, попавших под фильтр

  /* ── Показать строки ── */
  document.getElementById('previewRowsBtn')?.addEventListener('click', () => {

    const file = document.querySelector('input[name="excel"]').files[0];
    if (!file) return alert('Сначала выберите Excel-файл');

    /* какой фильтр выбран */
    const filt   = document.getElementById('filt').value;
    const custom = document.getElementById('customDays').value;
    const need   = (filt === 'all')    ? null
                 : (filt === 'custom')? parseInt(custom || '0', 10)
                                        : parseInt(filt, 10);

    const fr = new FileReader();
    fr.onload = ev => {
      const wb   = XLSX.read(ev.target.result, { type: 'binary' });
      const ws   = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws, { header: 1 });

      matched = [];
      for (let i = 1; i < rows.length; i++) {                  // 0-я строка — заголовки
        const r   = rows[i];
        const exp = daysLeft(r[5]);
        if (need === null || exp === need) {
          matched.push({A:r[0], B:r[1], C:r[2], D:r[3], E:r[4], F:r[5], expiry_days: exp});
        }
        if (need === null && matched.length === 200) break;    // «любой» → первые 200
      }

      /* выводим в таблицу */
      document.getElementById('rowsPreviewBody').innerHTML = matched.map(r =>
        `<tr>${['A','B','C','D','E','F'].map(c=>`<td>${r[c]??''}</td>`).join('')}</tr>`
      ).join('');
      document.getElementById('rowsCnt').textContent = matched.length;
      bootstrap.Modal.getOrCreateInstance('#rowsPreviewModal').show();
    };
    fr.readAsBinaryString(file);
  });

  /* ── Предпросмотр шаблона ── */
  document.getElementById('previewTemplateBtn')?.addEventListener('click', () => {
    if (!matched.length) return alert('Сначала нажмите «Показать строки»');

    const subj = document.querySelector('input[name="subject"]').value;
    const body = document.querySelector('textarea[name="body"]').value;
    const row  = matched[0];                       // первая подходящая строка

    document.getElementById('tmplSubj').textContent = render(subj, row);
    document.getElementById('tmplBody').innerHTML   = render(body, row);
    bootstrap.Modal.getOrCreateInstance('#tmplPreviewModal').show();
  });

});

